﻿namespace Floricultura
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            ID = new DataGridViewTextBoxColumn();
            ITEM = new DataGridViewTextBoxColumn();
            CATEGORIA = new DataGridViewTextBoxColumn();
            QUANT = new DataGridViewTextBoxColumn();
            MÁXIMO = new DataGridViewTextBoxColumn();
            MINÍMA = new DataGridViewTextBoxColumn();
            PU = new DataGridViewTextBoxColumn();
            VALOR = new DataGridViewTextBoxColumn();
            STATUS = new DataGridViewTextBoxColumn();
            groupBox1 = new GroupBox();
            textBox1 = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { ID, ITEM, CATEGORIA, QUANT, MÁXIMO, MINÍMA, PU, VALOR, STATUS });
            dataGridView1.Location = new Point(12, 218);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(762, 281);
            dataGridView1.TabIndex = 1;
            // 
            // ID
            // 
            ID.HeaderText = "ID";
            ID.Name = "ID";
            // 
            // ITEM
            // 
            ITEM.HeaderText = "ITEM";
            ITEM.Name = "ITEM";
            // 
            // CATEGORIA
            // 
            CATEGORIA.HeaderText = "CATEGORIA";
            CATEGORIA.Name = "CATEGORIA";
            // 
            // QUANT
            // 
            QUANT.HeaderText = "QUANT";
            QUANT.Name = "QUANT";
            // 
            // MÁXIMO
            // 
            MÁXIMO.HeaderText = "MÁXIMO";
            MÁXIMO.Name = "MÁXIMO";
            // 
            // MINÍMA
            // 
            MINÍMA.HeaderText = "MINÍMA";
            MINÍMA.Name = "MINÍMA";
            // 
            // PU
            // 
            PU.HeaderText = "PU";
            PU.Name = "PU";
            // 
            // VALOR
            // 
            VALOR.HeaderText = "VALOR";
            VALOR.Name = "VALOR";
            // 
            // STATUS
            // 
            STATUS.HeaderText = "STATUS";
            STATUS.Name = "STATUS";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(textBox3);
            groupBox1.Controls.Add(textBox2);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(textBox1);
            groupBox1.Location = new Point(531, 38);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(243, 135);
            groupBox1.TabIndex = 2;
            groupBox1.TabStop = false;
            groupBox1.Text = "Status";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(123, 23);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(100, 23);
            textBox1.TabIndex = 0;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(11, 26);
            label1.Name = "label1";
            label1.Size = new Size(109, 15);
            label1.TabIndex = 1;
            label1.Text = "Abaixo do Minimo:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(11, 53);
            label2.Name = "label2";
            label2.Size = new Size(95, 15);
            label2.TabIndex = 2;
            label2.Text = "Entre Min - Max:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(11, 89);
            label3.Name = "label3";
            label3.Size = new Size(87, 15);
            label3.TabIndex = 3;
            label3.Text = "Acima do Max:";
            label3.Click += label3_Click;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(109, 50);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(114, 23);
            textBox2.TabIndex = 3;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(104, 81);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(119, 23);
            textBox3.TabIndex = 4;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 565);
            Controls.Add(groupBox1);
            Controls.Add(dataGridView1);
            Name = "Form2";
            Text = "Controle de Estoque";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn ID;
        private DataGridViewTextBoxColumn ITEM;
        private DataGridViewTextBoxColumn CATEGORIA;
        private DataGridViewTextBoxColumn QUANT;
        private DataGridViewTextBoxColumn MÁXIMO;
        private DataGridViewTextBoxColumn MINÍMA;
        private DataGridViewTextBoxColumn PU;
        private DataGridViewTextBoxColumn VALOR;
        private DataGridViewTextBoxColumn STATUS;
        private GroupBox groupBox1;
        private Label label2;
        private Label label1;
        private TextBox textBox1;
        private Label label3;
        private TextBox textBox3;
        private TextBox textBox2;
    }
}