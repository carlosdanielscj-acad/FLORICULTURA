﻿namespace Floricultura
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            groupBox2 = new GroupBox();
            groupBox3 = new GroupBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            textBox5 = new TextBox();
            textBox6 = new TextBox();
            dataGridView1 = new DataGridView();
            RS = new DataGridViewTextBoxColumn();
            TELEFONE = new DataGridViewTextBoxColumn();
            CONTATO = new DataGridViewTextBoxColumn();
            EMAIL = new DataGridViewTextBoxColumn();
            groupBox4 = new GroupBox();
            label7 = new Label();
            label8 = new Label();
            comboBox1 = new ComboBox();
            button1 = new Button();
            button2 = new Button();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            textBox7 = new TextBox();
            textBox8 = new TextBox();
            textBox9 = new TextBox();
            groupBox5 = new GroupBox();
            checkBox1 = new CheckBox();
            checkBox2 = new CheckBox();
            checkBox3 = new CheckBox();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            groupBox4.SuspendLayout();
            groupBox5.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(textBox6);
            groupBox1.Controls.Add(textBox4);
            groupBox1.Controls.Add(textBox5);
            groupBox1.Controls.Add(textBox3);
            groupBox1.Controls.Add(textBox2);
            groupBox1.Controls.Add(textBox1);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(12, 23);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(328, 206);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "ITEM DO PEDIDO";
            groupBox1.Enter += groupBox1_Enter;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(groupBox5);
            groupBox2.Controls.Add(textBox9);
            groupBox2.Controls.Add(textBox8);
            groupBox2.Controls.Add(textBox7);
            groupBox2.Controls.Add(label11);
            groupBox2.Controls.Add(label10);
            groupBox2.Controls.Add(label9);
            groupBox2.Location = new Point(12, 244);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(328, 221);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "DADOS DO PEDIDO";
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(comboBox1);
            groupBox3.Controls.Add(label8);
            groupBox3.Controls.Add(groupBox4);
            groupBox3.Location = new Point(360, 23);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(472, 321);
            groupBox3.TabIndex = 2;
            groupBox3.TabStop = false;
            groupBox3.Text = "DADOS DO FORNECEDOR";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(13, 19);
            label1.Name = "label1";
            label1.Size = new Size(43, 15);
            label1.TabIndex = 0;
            label1.Text = "Nome:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(13, 45);
            label2.Name = "label2";
            label2.Size = new Size(61, 15);
            label2.TabIndex = 1;
            label2.Text = "Categoria:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(13, 82);
            label3.Name = "label3";
            label3.Size = new Size(125, 15);
            label3.TabIndex = 2;
            label3.Text = "Quantidade a solicitar:";
            label3.Click += label3_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(11, 108);
            label4.Name = "label4";
            label4.Size = new Size(107, 15);
            label4.TabIndex = 3;
            label4.Text = "Preço por unidade:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(13, 140);
            label5.Name = "label5";
            label5.Size = new Size(95, 15);
            label5.TabIndex = 4;
            label5.Text = "Total da compra:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(13, 169);
            label6.Name = "label6";
            label6.Size = new Size(54, 15);
            label6.TabIndex = 5;
            label6.Text = "Validade:";
            label6.Click += label6_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(88, 16);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(209, 23);
            textBox1.TabIndex = 6;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(97, 45);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(200, 23);
            textBox2.TabIndex = 7;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(161, 79);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(136, 23);
            textBox3.TabIndex = 8;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(144, 108);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(153, 23);
            textBox4.TabIndex = 9;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(132, 137);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(165, 23);
            textBox5.TabIndex = 3;
            // 
            // textBox6
            // 
            textBox6.Location = new Point(88, 166);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(209, 23);
            textBox6.TabIndex = 4;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { RS, TELEFONE, CONTATO, EMAIL });
            dataGridView1.Location = new Point(8, 20);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(442, 214);
            dataGridView1.TabIndex = 0;
            // 
            // RS
            // 
            RS.HeaderText = "RAZÃO SOCIAL";
            RS.Name = "RS";
            // 
            // TELEFONE
            // 
            TELEFONE.HeaderText = "RAZÃO SOCIAL";
            TELEFONE.Name = "TELEFONE";
            // 
            // CONTATO
            // 
            CONTATO.HeaderText = "CONTATO";
            CONTATO.Name = "CONTATO";
            // 
            // EMAIL
            // 
            EMAIL.HeaderText = "EMAIL";
            EMAIL.Name = "EMAIL";
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(dataGridView1);
            groupBox4.Location = new Point(6, 59);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(456, 240);
            groupBox4.TabIndex = 1;
            groupBox4.TabStop = false;
            groupBox4.Text = "INFORMAÇÕES";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(0, 0);
            label7.Name = "label7";
            label7.Size = new Size(38, 15);
            label7.TabIndex = 3;
            label7.Text = "label7";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(14, 24);
            label8.Name = "label8";
            label8.Size = new Size(70, 15);
            label8.TabIndex = 2;
            label8.Text = "Fornecedor:";
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(90, 21);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(117, 23);
            comboBox1.TabIndex = 3;
            // 
            // button1
            // 
            button1.Location = new Point(481, 374);
            button1.Name = "button1";
            button1.Size = new Size(106, 23);
            button1.TabIndex = 4;
            button1.Text = "SALVAR PEDIDO";
            button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Location = new Point(621, 374);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 5;
            button2.Text = "CANCELAR";
            button2.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(11, 26);
            label9.Name = "label9";
            label9.Size = new Size(95, 15);
            label9.TabIndex = 0;
            label9.Text = "Total da compra:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(11, 57);
            label10.Name = "label10";
            label10.Size = new Size(109, 15);
            label10.TabIndex = 1;
            label10.Text = "Data de solicitação:";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(11, 85);
            label11.Name = "label11";
            label11.Size = new Size(113, 15);
            label11.TabIndex = 2;
            label11.Text = "Previsão de entrega:";
            // 
            // textBox7
            // 
            textBox7.Location = new Point(114, 22);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(183, 23);
            textBox7.TabIndex = 3;
            // 
            // textBox8
            // 
            textBox8.Location = new Point(123, 55);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(174, 23);
            textBox8.TabIndex = 4;
            // 
            // textBox9
            // 
            textBox9.Location = new Point(123, 84);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(174, 23);
            textBox9.TabIndex = 5;
            textBox9.TextChanged += textBox9_TextChanged;
            // 
            // groupBox5
            // 
            groupBox5.Controls.Add(checkBox3);
            groupBox5.Controls.Add(checkBox2);
            groupBox5.Controls.Add(checkBox1);
            groupBox5.Location = new Point(11, 114);
            groupBox5.Name = "groupBox5";
            groupBox5.Size = new Size(290, 89);
            groupBox5.TabIndex = 6;
            groupBox5.TabStop = false;
            groupBox5.Text = "STATUS DO PEDIDO";
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(14, 31);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(76, 19);
            checkBox1.TabIndex = 3;
            checkBox1.Text = "Pendente";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.Location = new Point(14, 56);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(73, 19);
            checkBox2.TabIndex = 4;
            checkBox2.Text = "Entregue";
            checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            checkBox3.AutoSize = true;
            checkBox3.Location = new Point(161, 31);
            checkBox3.Name = "checkBox3";
            checkBox3.Size = new Size(86, 19);
            checkBox3.TabIndex = 5;
            checkBox3.Text = "Em trânsito";
            checkBox3.UseVisualStyleBackColor = true;
            // 
            // Form6
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(845, 487);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label7);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "Form6";
            Text = "X";
            Load += Form6_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            groupBox4.ResumeLayout(false);
            groupBox5.ResumeLayout(false);
            groupBox5.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private GroupBox groupBox3;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox textBox4;
        private TextBox textBox3;
        private TextBox textBox2;
        private TextBox textBox1;
        private TextBox textBox5;
        private TextBox textBox6;
        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn RS;
        private DataGridViewTextBoxColumn TELEFONE;
        private DataGridViewTextBoxColumn CONTATO;
        private DataGridViewTextBoxColumn EMAIL;
        private Label label11;
        private Label label10;
        private Label label9;
        private ComboBox comboBox1;
        private Label label8;
        private GroupBox groupBox4;
        private Label label7;
        private Button button1;
        private Button button2;
        private TextBox textBox9;
        private TextBox textBox8;
        private TextBox textBox7;
        private GroupBox groupBox5;
        private CheckBox checkBox3;
        private CheckBox checkBox2;
        private CheckBox checkBox1;
    }
}